window.highchartsDataArray = []; // Ensure highchartsDataArray is initialized

export function generateHighcharts(container, type, chartData, showTitle = true, title = '', highchartsId = null) {
    let categories = [];
    let series = [];

    // Check if chartData is valid
    if (chartData && chartData.data && chartData.metadata) {
        // Dynamically set categories based on the structure of the chartData
        categories = chartData.data.categories || chartData.data.months || [];

        // Find the key that holds the series data
        const seriesKey = Object.keys(chartData.data).find(key => Array.isArray(chartData.data[key]) && chartData.data[key].length > 0 && chartData.data[key][0].values);

        if (seriesKey) {
            // Dynamically generate series based on the structure of the chartData
            series = chartData.data[seriesKey].map(item => ({
                name: item.region || item.category,
                data: item.values
            }));
        } else {
            console.error('Unsupported data structure for series.');
            return;
        }

        const options = {
            chart: { type: type, renderTo: container.id },
            title: { text: showTitle ? title : null },
            xAxis: { categories: categories },
            yAxis: { title: { text: chartData.metadata.units } },
            series: series
        };

        const chart = Highcharts.chart(options);
        const highchartsIndex = highchartsId !== null ? highchartsId : chart.index;
        container.setAttribute('data-highcharts-chart', highchartsIndex);

        window.highchartInstances[container.id] = chart;
        window.chartDataTemp[container.id] = chartData;

        window.highchartsDataArray.push({
            containerId: container.id,
            options: chart.options
        });

        return chart;
    } else {
        console.error('Invalid chart data structure.');
    }
}

export function saveLayoutWithCharts() {
    const layoutName = prompt("Enter layout name:");
    if (layoutName) {
        const layout = window.grid.save().map(item => {
            const el = item.el || document.querySelector(`.grid-stack-item[gs-x="${item.x}"][gs-y="${item.y}"]`);
            if (!el) return null;
            return {
                x: el.getAttribute('gs-x'),
                y: el.getAttribute('gs-y'),
                width: el.getAttribute('gs-w'),
                height: el.getAttribute('gs-h'),
                content: el.innerHTML
            };
        }).filter(item => item !== null);

        window.highchartsDataArray = window.highchartsDataArray.map(data => {
            const chart = Highcharts.charts.find(chart => chart && chart.renderTo.id === data.containerId);
            if (chart) {
                data.options = getCompleteChartOptions(chart);
            }
            return data;
        });

        window.gridItemDimensions = layout.map(item => ({
            x: item.x,
            y: item.y,
            width: item.width,
            height: item.height
        }));

        const savedLayouts = JSON.parse(localStorage.getItem('savedLayouts')) || {};
        savedLayouts[layoutName] = {
            layout: layout,
            highchartsDataArray: window.highchartsDataArray,
            gridItemDimensions: window.gridItemDimensions
        };

        localStorage.setItem('savedLayouts', JSON.stringify(savedLayouts));
    }
}

export function loadLayoutWithCharts(layoutName) {
    window.loading = true;
    const savedLayouts = JSON.parse(localStorage.getItem('savedLayouts'));
    const layoutData = savedLayouts ? savedLayouts[layoutName] : null;

    if (layoutData) {
        window.grid.removeAll();

        layoutData.layout.forEach(item => {
            const el = document.createElement('div');
            el.className = 'grid-stack-item';
            el.setAttribute('gs-x', item.x);
            el.setAttribute('gs-y', item.y);
            el.setAttribute('gs-w', item.width);
            el.setAttribute('gs-h', item.height);
            el.innerHTML = item.content;
            window.grid.addWidget(el);
        });

        window.gridItemDimensions = layoutData.gridItemDimensions;

        setTimeout(() => {
            layoutData.highchartsDataArray.forEach(data => {
                initializeHighcharts(data.containerId, data.options);
            });
            window.loading = false;
        }, 1000);
    } else {
        alert("Layout not found.");
        window.loading = false;
    }
}

function getCompleteChartOptions(chart) {
    return {
        chart: chart.options.chart,
        title: chart.options.title,
        subtitle: chart.options.subtitle,
        series: chart.options.series,
        xAxis: chart.options.xAxis,
        yAxis: chart.options.yAxis,
        legend: chart.options.legend,
        tooltip: chart.options.tooltip,
        plotOptions: chart.options.plotOptions,
        exporting: chart.options.exporting,
        annotations: chart.options.annotations,
        credits: chart.options.credits,
        noData: chart.options.noData,
        responsive: chart.options.responsive
    };
}

function initializeHighcharts(containerId, options) {
    const container = document.getElementById(containerId);
    if (container) {
        options.chart.renderTo = containerId;
        const chart = Highcharts.chart(options);
        Highcharts.charts[chart.index] = chart;

        setTimeout(() => {
            chart.reflow();
        }, 0);
    }
}

export function updateSavedLayouts() {
    const savedLayouts = JSON.parse(localStorage.getItem('savedLayouts')) || {};
    $('#localStorageContent').text(JSON.stringify(savedLayouts, null, 2));
}

export function updateCurrentLayoutContent() {
    if (window.loading) return;
    const currentLayoutContent = window.grid.save().map(item => {
        const el = item.el || document.querySelector('.grid-stack-item');
        if (!el) return null;
        return {
            x: el.getAttribute('gs-x'),
            y: el.getAttribute('gs-y'),
            width: el.getAttribute('gs-w'),
            height: el.getAttribute('gs-h'),
            content: el.innerHTML
        };
    }).filter(item => item !== null);

    localStorage.setItem('currentLayoutContent', JSON.stringify(currentLayoutContent));
}

export function updateHighchartsDataArray() {
    if (window.loading) return;
    const updatedHighchartsDataArray = Highcharts.charts.map(chart => {
        if (chart) {
            return {
                containerId: chart.renderTo.id,
                options: getCompleteChartOptions(chart)
            };
        }
        return null;
    }).filter(data => data !== null);

    localStorage.setItem('highchartsDataArray', JSON.stringify(updatedHighchartsDataArray));
}