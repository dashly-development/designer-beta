window.comments = []; // Ensure comments array is initialized

export function initCommentMode() {
  window.commentMode = true;
  window.isDragging = false;
  enableCommentDragging();
  $('.comment-icon').removeClass('hidden');
  $('.grid-stack-item-content').css('pointer-events', 'none').addClass('comment-mode');
  $('.grid-stack').addClass('comment-mode');
  disableGridStackInteractions();
  disableChartInteractions();
}

export function initDesignMode() {
  window.commentMode = false;
  window.isDragging = false;
  $('.comment-icon').removeClass('hidden');
  $('.grid-stack-item-content').css('pointer-events', 'auto').removeClass('comment-mode');
  $('.grid-stack').removeClass('comment-mode');
  enableGridStackInteractions();
  enableChartInteractions();
}

export function openCommentModal(e, context) {
  if (window.commentMode && !$(e.target).hasClass('comment-icon') && !window.isDragging && !$(e.target).closest('.grid-stack-item').length) {
    $('#commentModalLabel').text('Add Comment');
    $('#commentInput').val('');
    $('#saveCommentBtn').show();
    $('#updateCommentBtn').hide();
    $('#deleteCommentBtn').hide();
    $('#commentModal').modal('show');
    window.currentCommentId = null;
    const posX = e.pageX - $(context).offset().left;
    const posY = e.pageY - $(context).offset().top;

    $('#saveCommentBtn').off('click').on('click', function () {
      const commentText = $('#commentInput').val();
      if (commentText) {
        const commentId = new Date().getTime();
        window.comments.push({ id: commentId, text: commentText, x: posX, y: posY });
        renderComment(commentId, posX, posY);
        $('#commentModal').modal('hide');
      }
    });

    $('#commentInput').off('keypress').on('keypress', function (e) {
      if (e.which === 13) {
        $('#saveCommentBtn').click();
        e.preventDefault();
      }
    });
  }
}

export function renderComment(id, x, y) {
  const icon = $('<span>')
    .addClass('comment-icon')
    .attr('data-id', id)
    .css({ top: y, left: x })
    .text('💬')
    .append('<div class="comment-popup"></div>')
    .hover(
      function () {
        const comment = window.comments.find(c => c.id === id);
        $(this).find('.comment-popup').text(comment.text);
      },
      function () {
        $(this).find('.comment-popup').text('');
      }
    );
  icon.on('click', function () {
    if (window.isDragging) return;
    if (!window.commentMode) return;
    const comment = window.comments.find(c => c.id === id);
    $('#commentModalLabel').text('Edit Comment');
    $('#commentInput').val(comment.text);
    $('#saveCommentBtn').hide();
    $('#updateCommentBtn').show();
    $('#deleteCommentBtn').show();
    $('#commentModal').modal('show');
    window.currentCommentId = id;
    $('#updateCommentBtn').off('click').on('click', function () {
      const updatedText = $('#commentInput').val();
      if (updatedText) {
        comment.text = updatedText;
        $('#commentModal').modal('hide');
      }
    });

    $('#deleteCommentBtn').off('click').on('click', function () {
      if (confirm('Are you sure you want to delete this comment?')) {
        window.comments = window.comments.filter(c => c.id !== window.currentCommentId);
        $(`.comment-icon[data-id="${window.currentCommentId}"]`).remove();
        $('#commentModal').modal('hide');
      }
    });

    $('#commentInput').off('keypress').on('keypress', function (e) {
      if (e.which === 13) {
        $('#updateCommentBtn').click();
        e.preventDefault();
      }
    });
  });
  $('.grid-stack').append(icon);
  if (window.commentMode) {
    enableCommentDragging();
  }
}

function enableCommentDragging() {
  $('.comment-icon').each(function () {
    if (!$(this).data('ui-draggable')) {
      $(this).draggable({
        containment: '.grid-stack',
        start: function () {
          window.isDragging = true;
        },
        stop: function (event, ui) {
          const commentId = $(this).data('id');
          const comment = window.comments.find(c => c.id === commentId);
          if (comment) {
            comment.x = ui.position.left;
            comment.y = ui.position.top;
          }
          setTimeout(() => {
            window.isDragging = false;
          }, 100);
        }
      });
    }
  });
}

function disableGridStackInteractions() {
  window.grid.movable('.grid-stack-item', false);
  window.grid.resizable('.grid-stack-item', false);
  $('.grid-stack-item').css('pointer-events', 'none');
}

function enableGridStackInteractions() {
  window.grid.movable('.grid-stack-item', true);
  window.grid.resizable('.grid-stack-item', true);
  $('.grid-stack-item').css('pointer-events', 'auto');
}

function disableChartInteractions() {
  $('.grid-stack-item-content > div').each(function () {
    $(this).css('pointer-events', 'none');
  });
}

function enableChartInteractions() {
  $('.grid-stack-item-content > div').each(function () {
    $(this).css('pointer-events', 'auto');
  });
}