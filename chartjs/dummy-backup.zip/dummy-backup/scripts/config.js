// scripts/config.js

window.businessMetrics = {
  sales: ["Units Sold", "Sales Revenue", "Average Order Value", "Sales Growth Rate", "Sales by Region", "Sales by Product Category"],
  marketing: ["Ad Impressions", "Click Through Rate", "Cost Per Click", "Leads Generated", "Conversion Rate", "Customer Acquisition Cost", "Social Media Engagement", "Email Campaign Performance"],
  financial: ["Total Revenue", "Recurring Revenue", "Revenue Growth Rate", "Operating Expenses", "Marketing Expenses", "Employee Salaries", "Net Profit Margin", "Gross Profit", "EBITDA", "Earnings Per Share", "Return on Investment", "Stock Prices", "Dividend Yield"],
  customer: ["Active Users", "Customer Satisfaction Score", "Net Promoter Score", "Churn Rate", "Customer Lifetime Value", "Support Tickets", "Average Resolution Time", "Support Satisfaction"],
  website: ["Page Views", "Unique Visitors", "Session Duration", "Bounce Rate", "Click Paths", "Heatmaps", "Exit Rates", "Sign Up Rate", "Checkout Abandonment Rate", "Form Completion Rate"],
  operational: ["Units Produced", "Production Downtime", "Production Cost Per Unit", "Inventory Levels", "Order Fulfillment Time", "Supply Chain Costs", "Shipping Times", "Delivery Accuracy", "Transportation Costs"],
  hr: ["Employee Count", "Employee Turnover Rate", "Average Tenure", "Employee Satisfaction", "Time to Hire", "Cost Per Hire", "Offer Acceptance Rate", "Training Completion Rate", "Training Costs"],
  it: ["Server Uptime", "Response Times", "Error Rates", "Security Incidents", "Time to Resolve Security Issues", "Compliance Rates", "Number of Deployments", "Bug Fix Rate", "Feature Development Rate"],
  health_safety: ["Health Incidents", "Average Recovery Time", "Safety Incidents", "Safety Training Completion Rate", "Compliance with Safety Regulations"]
};

window.comments = [];
window.highchartsDataArray = [];
window.chartDataTemp = {};
window.highchartInstances = {};
window.chartCounter = 0;
window.pendingChartData = null;
window.pendingChartType = null;
window.pendingChartId = null;
window.commentMode = false;
window.currentCommentId = null;
window.isDragging = false;
window.gridItemDimensions = [];
window.loading = false;