import { initCommentMode, initDesignMode, openCommentModal } from './commentUtils.js';
import { handleBusinessAreaChange, handleGenerateChart, saveChartName } from './gridUtils.js';

export function attachEventHandlers() {
    $('#commentModeBtn').on('click', initCommentMode);
    $('#designModeBtn').on('click', initDesignMode);

    $('#commentModal').on('shown.bs.modal', function () {
        $('#commentInput').focus();
    });

    $('.grid-stack').on('click', function (e) {
        openCommentModal(e, this);
    });

    $('#businessAreaSelect').on('change', handleBusinessAreaChange);
    $('#generateChartBtn').on('click', handleGenerateChart);
    $('#saveChartName').on('click', saveChartName);

    $('#loadLayoutBtn').on('click', function () {
        const layoutName = prompt("Enter layout name to load:");
        if (layoutName) {
            loadLayoutWithCharts(layoutName);
        }
    });

    $('#saveLayoutBtn').on('click', saveLayoutWithCharts);
}