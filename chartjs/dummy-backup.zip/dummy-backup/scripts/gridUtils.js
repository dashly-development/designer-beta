import { generateHighcharts, updateCurrentLayoutContent, updateHighchartsDataArray } from './chartUtils.js';

export function initGridStack() {
  window.grid = GridStack.init({
    cellHeight: 70,
    acceptWidgets: true,
    removable: true,
    removeTimeout: 100,
    dragIn: '.newWidget',
    dragInOptions: { revert: 'invalid', scroll: false, appendTo: 'body', helper: 'clone' }
  });

  grid.movable('.grid-stack-item', true);
  grid.resizable('.grid-stack-item', true);

  grid.on('change', function (event, items) {
    updateCurrentLayoutContent();
    updateHighchartsDataArray();
  });

  grid.on('resizestop', function (event, element) {
    const chartContainer = $(element).find('.chart-container');
    const highchartsIndex = chartContainer.attr('data-highcharts-chart');
    const chart = Highcharts.charts[highchartsIndex];
    if (chart) {
      chart.reflow();
    }
  });
}

export function handleBusinessAreaChange() {
  const businessArea = $('#businessAreaSelect').val();
  const metrics = window.businessMetrics[businessArea]; // Ensure businessMetrics is defined
  if (!metrics) {
    console.error(`No metrics found for business area: ${businessArea}`);
    return;
  }
  $('#metricSelect').empty().append('<option value="" disabled selected>Select Metric</option>');
  metrics.forEach(metric => {
    $('#metricSelect').append(`<option value="${metric.toLowerCase().replace(/ /g, '_')}">${metric}</option>`);
  });
}

export function handleGenerateChart() {
  const businessArea = $('#businessAreaSelect').val();
  const metric = $('#metricSelect').val();
  const chartType = $('#chartTypeSelect').val();
  window.currentChartType = chartType;
  if (!businessArea || !metric || !chartType) {
    alert("Please select business area, metric, and chart type.");
    return;
  }

  $('#generateChartBtn').prop('disabled', true);

  const dataFilePath = `/dummy/data/dummy/${businessArea}/${metric}.json`;
  fetch(dataFilePath)
    .then(response => response.json())
    .then(chartData => {
      window.chartCounter++;
      window.pendingChartId = `chart-container-${window.chartCounter}`;
      window.pendingChartType = chartType;
      window.pendingChartData = chartData;

      $('#chartNameModal').modal('show');
      $('#generateChartBtn').prop('disabled', false);
    })
    .catch(error => {
      console.error('Error fetching dummy data:', error);
      $('#generateChartBtn').prop('disabled', false);
    });
}

export function saveChartName() {
  const chartName = $('#chartNameInput').val();
  if (!chartName) {
    alert("Please enter a chart name.");
    return;
  }

  const chartHtml = `
    <div class="grid-stack-item" gs-w="6" gs-h="4">
      <div class="grid-stack-item-content" style="padding: 5px;">
        <div class="widget-title">
          <div class="widget-name">${chartName}</div>
          <span class="edit-btn">✎</span>
          <span class="save-btn" style="display: none;">✔</span>
        </div>
        <div class="chart-container" id="${window.pendingChartId}" style="width: 100%; height: 100%;"></div>
      </div>
    </div>
  `;
  const el = $(chartHtml).get(0);

  $('#chartNameModal').modal('hide');
  $('#chartNameInput').val('');

  window.grid.addWidget(el, {
    width: 6,
    height: 4,
    autoPosition: true
  });

  setTimeout(() => {
    const container = document.getElementById(window.pendingChartId);
    if (container) {
      const chart = generateHighcharts(container, window.pendingChartType, window.pendingChartData, true, chartName);
      updateCurrentLayoutContent();
      updateHighchartsDataArray();
    }
  }, 0);
}