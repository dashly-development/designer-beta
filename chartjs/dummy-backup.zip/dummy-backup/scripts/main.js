import { initCommentMode, initDesignMode, openCommentModal, renderComment } from './commentUtils.js';
import { generateHighcharts, saveLayoutWithCharts, loadLayoutWithCharts, updateSavedLayouts, updateCurrentLayoutContent, updateHighchartsDataArray } from './chartUtils.js';
import { initGridStack, handleBusinessAreaChange, handleGenerateChart, saveChartName } from './gridUtils.js';

$(document).ready(function () {
    // Initialize GridStack
    initGridStack();

    // Event listeners for mode buttons
    $('#commentModeBtn').on('click', initCommentMode);
    $('#designModeBtn').on('click', initDesignMode);

    // Event listener for comment modal
    $('#commentModal').on('shown.bs.modal', function () {
        $('#commentInput').focus();
    });

    // Event listener for grid stack
    $('.grid-stack').on('click', function (e) {
        openCommentModal(e, this);
    });

    // Event listener for business area selection
    $('#businessAreaSelect').on('change', handleBusinessAreaChange);

    // Event listener for generating charts
    $('#generateChartBtn').on('click', handleGenerateChart);

    // Event listener for saving chart name
    $('#saveChartName').on('click', saveChartName);

    // Autofocus and save chart name on Enter key press
    $('#chartNameModal').on('shown.bs.modal', function () {
        $('#chartNameInput').focus().off('keypress').on('keypress', function (e) {
            if (e.which === 13) {
                saveChartName();  // Call the save function when Enter is pressed
                e.preventDefault();
            }
        });
    });

    // Event listener for loading layout
    $('#loadLayoutBtn').on('click', function () {
        const layoutName = prompt("Enter layout name to load:");
        if (layoutName) {
            loadLayoutWithCharts(layoutName);
        }
    });

    // Event listener for saving layout
    $('#saveLayoutBtn').on('click', saveLayoutWithCharts);

    // Initial updates
    updateSavedLayouts();
    updateCurrentLayoutContent();
    updateHighchartsDataArray();
});